exports.paginaInicial = (req, res) => {
    res.render("index")
    return //  dessa forma dizemos que nao queremos utilizar nenhum middleware
}

exports.trataPost = (req, res) => {
    res.send(req.body)
    return
}