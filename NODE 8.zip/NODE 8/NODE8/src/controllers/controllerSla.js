exports.trataSla = (req, res) => {
    res.send(`Deixei aqui seu recado`)
}

exports.mandaUmTrem = (req, res) => {
    res.send(`    <form action="/contato/form" method="POST"> <!-- CORRIGIDO: action="/opnion" -->
    Nome do cliente: <input type="text" name="santos">
    <button>Enviar</button>
    </form>`)
}

exports.trataSla02 = (req, res) => {
    res.send("Obrigado por enviar seu contato")
}

