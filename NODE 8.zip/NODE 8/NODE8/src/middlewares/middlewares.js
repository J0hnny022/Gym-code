module.exports = (req, res, next) => {
    
    //if (req.body.nome) {
        console.log()
        console.log(`Passei no middleware global`)
       // console.log(`Vi que vc postou ${req.body.nome}`)
        console.log()
    //}
    next()
}