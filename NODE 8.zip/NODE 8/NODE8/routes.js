const express = require("express")
const route = express.Router()
const homeController = require("./src/controllers/controllersHome.js")
const controllerContato = require("./src/controllers/controllerContato.js")
const controllerSla = require("./src/controllers/controllerSla.js")

// Agora todas as rotas começam com /routes
// rotas home
route.get("/", homeController.paginaInicial) // → GET /usuarios
route.post("/", homeController.trataPost)

//route.get("/opnion", controllerContato.opnionForm)
//route.post("/opnion", controllerContato.trataOpnion)

route.get("/contato", controllerSla.trataSla)
//route.get("/contato/form", controllerSla.mandaUmTrem)
//route.post("/contato/form", controllerSla.trataSla02)

module.exports = route // ← EXPORTA A ROTA