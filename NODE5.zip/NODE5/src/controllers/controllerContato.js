exports.opnionForm = (req, res) => {
    res.send(`
    <form action="/opnion" method="POST"> <!-- CORRIGIDO: action="/opnion" -->
    Nome do cliente: <input type="text" name="santos">
    <button>Enviar</button>
    </form>
    `)
}

exports.trataOpnion = (req, res) => {
    res.send("Sua opniao foi recebida")
}