const path = require("path");

module.exports = {
    mode: "production",
    entry: "./src/index.js", //qual é o arquivo de entrada da minha aplicação webpack
    output: {
        path: path.resolve(__dirname, "dist"), // tudo isso aqui é um modulo do node, pra dizer que, o meu diretorio base eu vou ter uma pasta chamada dist 
        // fazer a config de saída é quase a mesma coisa de fazer a config de entrada, só que, ele tem que entender como ele tem que gerar a saída 

        // no entry ele vai achar o arquivo para fazer a build
        // __dirname = "No nosso diretorio base" a gente vai inserir numa pasta dist

    
        filename: "bundle.js" // aqui vai ser o nome do arquivo
    },


    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,   // Ignora node_modules
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env']
                    },
                },
            }, {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            }
        ]
    },
    devtool: "source-map"
}