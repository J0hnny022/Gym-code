const express = require("express")
const route = express.Router()
const homeController = require("./src/controllers/controllersHome.js")
const controllerContato = require("./src/controllers/controllerContato.js")

// Agora todas as rotas começam com /routes
// rotas home
route.get("/", homeController.paginaInicial) // → GET /usuarios
route.post("/", homeController.trataPost)

route.get("/opnion", controllerContato.opnionForm)
route.post("/opnion", controllerContato.trataOpnion)

module.exports = route // ← EXPORTA A ROTA