module.exports = class Pessoa {
    constructor(nome, idade, sexo) {
        this.nome = nome
        this.idade = idade
        this.sexo = sexo
    }
}